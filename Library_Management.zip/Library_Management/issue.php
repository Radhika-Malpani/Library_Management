<?php
include "connection.php";
include "header.php";
$book_number = $_GET['book_number'];

				$sql = "select * from book_details where Book_number = '$book_number';";
				$query = mysql_query($sql);
				while($row = mysql_fetch_array($query))
				{
					$title = $row['Title'];
					$isbn = $row['Isbn'];
					$price = $row['Price'];
					$image = $row['Image'];
				}
				
				  
?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Issue Book</h5>
                                           <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
                                                <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Book Cover Page</h5>
                                        <img src="/Library_Management/book_images/<?php echo $image; ?>" height="200px" width="100px"/>
					

                                        
                                        </div>
                                    </div>
                                    
                            </div>
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Book and Student Details</h5>
                                        <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post" enctype="multipart/form-data">
            <table>
            
				<tr><td>Book Number</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_number" readonly="readonly" value="<?php echo $book_number;?>">
					<span class="focus-input100"></span>
				</div></td></tr>
                
               <tr><td>Book Title</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_title" readonly="readonly" value="<?php echo $title; ?>" >
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Book ISBN</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_isbn" readonly="readonly" value="<?php echo $isbn; ?>">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Price</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_price" readonly="readonly" value="<?php echo $price; ?>">
					<span class="focus-input100"></span>
				</div></td></tr>
                
               <tr><td>Student Mem_Id</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="mem_id">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                
                <tr><td>Issue Date</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="date" name="issue_date" >
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Return Date</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="date" name="return_date">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                
                </table>
                <br><br><br>
                <input type="submit" name="submit" value="Issue Book" />
				
</form>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            
            <?php 
			if(isset($_POST['submit']))
			{
				$book_number = $_POST['book_number'];
				$student_number = $_POST['mem_id'];
				$issue_date = $_POST['issue_date'];
				$return_date = $_POST['return_date'];
				
				
				$s2 = "select * from issue_details where Book_number='$book_number'";
				$q2=mysql_query($s2);
				$row2 = mysql_fetch_array($q2);
				if($row2 > 0)
				{
					echo "<script> alert('Already this book is issued'); </script>";
				}
				else
				{
				$s="insert into issue_details values('$book_number','$student_number','$issue_date','$return_date','0')";
				$q=mysql_query($s);	
				
				$s1="update book_details set Issue='Yes' where Book_number='$book_number'";
				$q1=mysql_query($s1);
			}}
			include "footer.php"; ?>
