<?php 
include "header.php";
include "connection.php";
?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                       
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Manage Fines</h5>
                                        <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post" enctype="multipart/form-data">
            <table>
            
				<tr><td>Enter the student Membership Number</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_no">
					<span class="focus-input100"></span>
				</div></td></tr>
                
               </table>
                <input type="submit" name="submit" value="View Issue Details" />
				
</form>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php
			if(isset($_POST['submit']))
			{
			$student = $_POST['student_no'];
			
			$sql = "select * from issue_details where Mem_Id = '$student'";
			
			$query = mysql_query($sql);
			
			?>
            <table border="1px solid grey">
            <?php
			while($row = mysql_fetch_array($query))
			{
				echo "<tr><td>";
				echo $row['Mem_Id'];
				echo "</td><td>";
				$book = $row['Book_number'];
				echo $row['Book_number'];
				echo "</td><td>";	
				?>
                <input type="button" value="Return Book" onclick="window.location.href='delete_issue_entry.php?id=<?php echo $book;?>'"/>
<?php            } ?>   
			
			 </table>
            <?php }
			include "footer.php";
			?>