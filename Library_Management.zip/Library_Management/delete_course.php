<?php 
include "connection.php";
$id = $_GET['id'];

$sql = "delete from course_details where Course_Id='$id';";
$query = mysql_query($sql);

if($query)
{
	echo "<script> var x = confirm('Delete $id?'); 
	if(x)
	{
		alert('Deleted $id successfully');
	}
	</script>";
}
else
{
	echo "<script> alert('$id could not be deleted!'); </script>";
}

?>