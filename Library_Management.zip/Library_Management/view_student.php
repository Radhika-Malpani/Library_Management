<?php include "connection.php";
include "header.php"?>
<style>
.bg-modal{
width:100%;
height:100%;
background-color: rgba(0, 0, 0, 0.7);
position:relative;
top:0;	
justify-content:center;
align-items:center;
display:none;
margin-left:100px;
margin-right:100px;
}
.modal-content{
	width:500px;
	height:600px;
	background-color:white;
	border-radius:4px;
	text-align:center;
	padding:20px;
}
</style>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
<?php
$sql = "select * from student_details";
$query = mysql_query($sql);?>
<div style="overflow-x:auto;">
<table border="1px solid grey" style="border-collapse:collapse;text-align:center">
<tr>
	<th>PHOTO</th>
    <th>MEMBERSHIP_NO</th>
    <th>FIRST NAME</th>
    <th>MIDDLE NAME</th>
    <th>LAST NAME</th>
    <th>EMAIL</th>
    <th>COURSE</th>
    <th>YEAR</th>
    <th>PHONE_NO</th>
    <th>ADDRESS</th>
    <th>CITY</th>
    <th>STATE</th>
    <th>PIN CODE</th>
    <th>ACTION</th>
</tr>

<?php
while($row = mysql_fetch_array($query))
{
	
	echo "<tr><td>";
	$image = $row['Photo'];
	?>
    <img src="/Library_Management/student_images/<?php echo $image; ?>" height="100px" width="70px" />
    <?php
	echo "</td><td>";
	echo $row['Membership_Id'];
	$membership_number = $row['Membership_Id'];
	echo "</td><td>";
	
	
	
	$First_Name = $row['First_Name'];
	echo $row['First_Name'];
	echo "</td><td>";
	
	
	echo $row['Middle_Name'];
	$Middle_Name = $row['Middle_Name'];
	echo "</td><td>";
	
	
	echo $row['Last_Name'];
	$Last_Name = $row['Last_Name'];
	echo "</td><td>";
	
	
	echo $row['Email'];
	$Email = $row['Email'];
	echo "</td><td>";
	
	
	echo $row['Course'];
	$Course = $row['Course'];
	echo "</td><td>";
	
	
	echo $row['Year'];
	$Year = $row['Year'];
	echo "</td><td>";
	
	
	echo $row['Phone_Number'];
	$Phone_Number = $row['Phone_Number'];
	echo "</td><td>";
	
	echo $row['Address'];
	$Address = $row['Address'];
	echo "</td><td>";
	
	echo $row['City'];
	$City = $row['City'];
	echo "</td><td>";
	
	echo $row['State'];
	$State = $row['State'];
	echo "</td><td>";
	
	echo $row['PinCode'];
	$PinCode = $row['PinCode'];
	echo "</td><td>";
	
	?>
    
    <input type = "button" id = "details" value = "Student Details" onclick="demo(<?php echo $membership_number; ?>,'<?php echo $First_Name; ?>','<?php echo $Middle_Name ; ?>','<?php echo $Last_Name ; ?>','<?php echo $Email ; ?>','<?php echo $Course ; ?>','<?php echo $Year ; ?>',<?php echo $Phone_Number ; ?>,'<?php echo $Address ; ?>','<?php echo $City ; ?>','<?php echo $State ; ?>',<?php echo $PinCode ; ?>)"/>
	</td></tr>
   
    <?php
}

?>
</table>
</div>
<script>
function demo(a,b,c,d,e,f,g,h,i,j,k,l)
{

document.getElementById('mymodal').style.display = 'block';
document.getElementById('a').innerHTML = a;
document.getElementById('b').innerHTML = b;
document.getElementById('c').innerHTML = c;
document.getElementById('d').innerHTML = d;
document.getElementById('e').innerHTML = e;
document.getElementById('f').innerHTML = f;
document.getElementById('g').innerHTML = g;
document.getElementById('h').innerHTML = h;
document.getElementById('i').innerHTML = i;
document.getElementById('j').innerHTML = j;
document.getElementById('k').innerHTML = k;
document.getElementById('l').innerHTML = l;



}

</script>
<!--Modal-->
<div class="bg-modal" id="mymodal">
<div class="modal-content">

<p id="a">

</p>
<p id="b">

</p>
<p id="c">

</p>
<p id="d">

</p>
<p id="e">

</p>
<p id="f">

</p>
<p id="g">

</p>
<p id="h">

</p>
<p id="i">

</p>
<p id="j">

</p>
<p id="k">

</p>
<p id="l">

</p>

<!--<p id="author"></p>
<p id="title"></p>
<p id="category"></p>
<p id="publisher"></p>
<p id="description"></p>
<p id="price"></p>
<p id="quantity"></p>
<p id="borrow"></p>-->

</div>
</div>

<?php include "footer.php"; ?>