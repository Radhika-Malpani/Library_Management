<?php 
include "header.php";
include "connection.php";
?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                       
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Add New Book Details</h5>
                                        <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post" enctype="multipart/form-data">
            <table>
            
				<tr><td>ISBN</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_isbn" readonly="readonly" value="<?php $no =  uniqid(rand()); echo substr($no,0,5); ?>">
					<span class="focus-input100"></span>
				</div></td></tr>
                
               <tr><td>Author Name</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_author" >
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Book Title</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_title">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Category</td><td><div class="wrap-input100 validate-input m-b-20">
					<select class="input100" type="text" name="student_course">
                    <option>Select Course</option>
                    <?php
					$s = "select Course_Name from course_details;";
					$q = mysql_query($s);
					while($r = mysql_fetch_array($q))
					{
					?>
      <option value="<?php echo $r['Course_Name'];?>"><?php echo $r['Course_Name'];?> </option>
                    <?php } ?>
                    </select>

                
               <tr><td>Publisher</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_publisher">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Book Description</td><td><div class="wrap-input100 validate-input m-b-20">
					<textarea class="input100" name="book_description">
					</textarea>
                    <span class="focus-input100"></span>
                    
				</div></td></tr>
                
                <tr><td>Price</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_price">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Quantity</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="book_quantity">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Upload Image</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="file" name="book_image">
					<span class="focus-input100"></span>
				</div></td></tr>
                </table>
                <br><br><br>
                <input type="submit" name="submit" value="Add Book Details" />
				
</form>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php
			if(isset($_POST['submit']))
			{
			$book_isbn = $_POST['book_isbn'];
			$book_author = $_POST['book_author'];	
			$book_title = $_POST['book_title'];	
			$book_category = $_POST['student_course'];	
			$book_publisher = $_POST['book_publisher'];	
			$book_description = $_POST['book_description'];	
			$book_price = $_POST['book_price'];	
			$book_quantity = $_POST['book_quantity'];	
			$book_image = $_FILES['book_image'];
			$image_name = $book_image['name'];
			$image_path = $book_image['tmp_name'];
			
			if($image_name!="")
			{
			move_uploaded_file($image_path,'book_images/'.$image_name);	
			
			}
			
			for($i=1; $i<=$book_quantity; $i++)
			{
				$uni = uniqid(rand());
				$uni = substr($uni,0,4);
			$sql = "insert into book_details values('$book_isbn','$uni','$book_author','$book_title','$book_category','$book_publisher','$book_description','$book_price','$image_name','No');";
			
			$query = mysql_query($sql);
			if($query)
			{
				echo "<script> Done </script>";
			}
			}
			
			}
            include "footer.php" ?>
