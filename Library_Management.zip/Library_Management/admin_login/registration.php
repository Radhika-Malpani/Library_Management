<?php session_start();
 include "connection.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	
	<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form" method="post">
				<span class="login100-form-title p-b-37">
					Library Admin Registration
				</span>

				<span>Name:</span><div class="wrap-input100">
					<input class="input100" type="text" name="admin_name" placeholder="Enter your Name" required>
					<span class="focus-input100"></span>
				</div>

				<span>Gender</span><div class="wrap-input100 " style="padding:20px 16px">
					<input type = "radio" name = "gender" value = "male">Male &nbsp;&nbsp;
                    <input type = "radio" name="gender" value = "female">Female
					<span class="focus-input100"></span>
				</div>

<span>Email:</span><div class="wrap-input100">
					<input class="input100" type="email" name="admin_email" placeholder="Enter your Email id" required>
					<span class="focus-input100"></span>
				</div>
                
                <span>Username:</span><div class="wrap-input100">
					<input class="input100" type="text" name="admin_username" placeholder="Enter Username" required>
					<span class="focus-input100"></span>
				</div>
                
                <span>Password:</span><div class="wrap-input100">
					<input class="input100" type="password" name="admin_password" placeholder="Enter Password" required>
					<span class="focus-input100"></span>
				</div>

<span>Country:</span><div class="wrap-input100">
					<input class="input100" type="text" name="admin_country" value = "India" readonly>
					<span class="focus-input100"></span>
				</div>

<span>State:</span><div class="wrap-input100 ">
					<select name = "admin_state" required>
                    <option>Select State</option>
                    <option>Maharashtra</option>
                    <option>Punjab</option>
                    <option>Kerala</option>
                    </select>
					<span class="focus-input100"></span>
				</div>


<span>City:</span><div class="wrap-input100 ">
					<select name = "admin_city" required>
                    <option>Select City </option>
                    <option>Pune</option>
                    <option>Mumbai</option>
                    <option>Kochi</option>
                    <option>Amritsar</option>
                    </select>
					<span class="focus-input100"></span>
				</div>


                <span>Pin Code:</span><div class="wrap-input100 ">
					<input class="input100" type="text" name="admin_pincode" placeholder="Enter Pin Code" required>
					<span class="focus-input100"></span>
				</div>

<span>Local Address:</span> <div class="wrap-input100 ">
					<textarea class="input100" name="admin_local_address" placeholder="Enter Local Address" required>
                    </textarea>
                    </div>
                    <input type = "checkbox" name = "same" >Same as Local Address.<br><br>
     <input type = "checkbox" name = "other" onclick = "document.getElementById('otheraddress').style = 'block'" >Other than Local Address.
     
                    <div id="otheraddress" style="display:none" class="wrap-input100">
					<textarea class="input100" name="admin_permanant_address" placeholder="Enter permanant Address">
                    </textarea>

					<span class="focus-input100"></span>
				</div>
<br><br>

<span>Mobile Number:</span><div class="wrap-input100" >
					<input class="input100" type="text" name="admin_mobile" placeholder="Enter your mobile" required>
					<span class="focus-input100"></span>
				</div>
              
            <span>Date of Joining:</span><div class="wrap-input100" >
					<input class="input100" type="text" name="admin_doj" placeholder="YYYY/MM/DD" required>
					<span class="focus-input100"></span>
				</div>  
                
			<div class="wrap-input100 ">
					<input class="input100" type="checkbox" name="admin_agree" required >Have you read the duties and responsibilities of Librarian?
					<span class="focus-input100"></span>
				</div>



				<div class="container-login100-form-btn">
					<button class="login100-form-btn" type="submit" name="register">
						Register
					</button>
				</div>

				
			</form>

			
		</div>
	</div>
	
	

<!--	<div id="dropDownSelect1"></div>
-->    

<?php 

if(isset($_POST['register']))
{
$admin_name=$_POST['admin_name'];
$gender=$_POST['gender'];	
$admin_email=$_POST['admin_email'];
$admin_username=$_POST['admin_username'];
$admin_password=$_POST['admin_password'];
$admin_country=$_POST['admin_country'];
$admin_state=$_POST['admin_state'];
$admin_city=$_POST['admin_city'];
$admin_pincode=$_POST['admin_pincode'];
$admin_local_address=$_POST['admin_local_address'];
$admin_permanant_address=$_POST['admin_permanant_address'];
$admin_mobile = $_POST['admin_mobile'];
$admin_doj = $_POST['admin_doj'];
$admin_agree=$_POST['admin_agree'];
$same = $_POST['same'];
if($admin_agree == 'on')
{
	$admin_agree = 'Yes';
}
else
{
	$admin_agree = 'No';
}
if($same == 'on')
{
	$admin_permanant_address = $admin_local_address;
}
	$sql= "insert into registration values(null,'$admin_name','$gender','$admin_email','$admin_username','$admin_password','$admin_country','$admin_state','$admin_city','$admin_pincode','$admin_local_address','$admin_permanant_address','$admin_mobile','$admin_doj','$admin_agree');";
	echo $sql;

	$query1 = mysql_query($sql);
	if($query1)
	{
		echo "<script> alert('Done'); </script>";
	}
	else
	{
		echo "<script> alert('Not Done'); </script>";
	}
}


?>

	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>