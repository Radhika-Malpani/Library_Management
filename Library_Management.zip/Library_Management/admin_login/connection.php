<?php
$host ="localhost";
$username= "root";
$pwd="";
$con=mysql_connect($host,$username,$pwd);
if(!$con)
{
	echo "could Not" .mysql_error();
}
mysql_select_db("library_management",$con);

?>