<?php include "connection.php";
include "header.php"; ?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Update Course Name</h5>
                                           <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">

<form method = "post">
Updated Name of Course<input type="text" name = "updated_course"  />
<input type="submit" name = "Change" value = "Change" />
</form>
											</div>
										   </div>
									</div>
								</div>
							</div>
						</div>
					</div>

<?php
$id = $_GET['id'];
if(isset($_POST['Change']))
{
$updated_course = $_POST['updated_course'];
$sql = "update course_details set Course_Name='$updated_course' where Course_Id='$id';";
echo $sql;
$query = mysql_query($sql);
}
include "footer.php"
?>