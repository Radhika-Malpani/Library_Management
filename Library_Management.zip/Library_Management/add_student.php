<?php 
include "header.php";
include "connection.php";
?>

<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">
                        <div class="row">
                        
                        
                            
                            
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Add New Student Details</h5>
                                        <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post" enctype="multipart/form-data">
            <table>
            
            <tr><td> Membership_Id </td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_membership_id" readonly="readonly" value="<?php $no = uniqid(rand()); echo substr($no,0,5);?>">
					<span class="focus-input100"></span>
				</div></td></tr>
                         
				<tr><td>First Name</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_first_name">
					<span class="focus-input100"></span>
				</div></td></tr>
                
               <tr><td>Middle Name</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_middle_name" >
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Last Name</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_last_name">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Email</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_email">
					<span class="focus-input100"></span>
				</div></td></tr>
                
               <tr><td>Course Name</td><td><div class="wrap-input100 validate-input m-b-20">
					<select class="input100" type="text" name="student_course">
                    <option>Select Course</option>
                    <?php
					$s = "select Course_Name from course_details;";
					$q = mysql_query($s);
					while($r = mysql_fetch_array($q))
					{
					?>
      <option value="<?php echo $r['Course_Name'];?>"><?php echo $r['Course_Name'];?> </option>
                    <?php } ?>
                    </select>
					<span class="focus-input100"></span>
				</div></td></tr>

                
                <tr><td>Year</td><td><div class="wrap-input100 validate-input m-b-20">
					<textarea class="input100" name="student_year">
					</textarea>
                    <span class="focus-input100"></span>
                    
				</div></td></tr>
                
                <tr><td>Phone No.</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_number">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Address</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_address">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>City</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_city">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>State</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_state">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Pin Code</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="text" name="student_pin_code">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                <tr><td>Upload Photo</td><td><div class="wrap-input100 validate-input m-b-20">
					<input class="input100" type="file" name="student_image">
					<span class="focus-input100"></span>
				</div></td></tr>
                
                				

                </table>
                <br><br><br>
                <input type="submit" name="submit" value="Add Student Details"  />
                
                <input type="button" value = "View Recent Details" onclick="document.getElementById('lol').style.display = 'block'" /> 
</form>
<?php
			if(isset($_POST['submit']))
			{
				$student_membership_id = $_POST['student_membership_id'];
			$student_first_name = $_POST['student_first_name'];
			$student_middle_name = $_POST['student_middle_name'];	
			$student_last_name = $_POST['student_last_name'];	
			$student_email = $_POST['student_email'];	
			$student_course = $_POST['student_course'];	
			$student_year = $_POST['student_year'];	
			$student_number = $_POST['student_number'];	
			$student_address = $_POST['student_address'];	
			$student_city = $_POST['student_city'];
			$student_state = $_POST['student_state'];
			$student_pin_code = $_POST['student_pin_code'];
			$student_image = $_FILES['student_image'];
			$image_name = $student_image['name'];
			$image_path = $student_image['tmp_name'];
			
			if($image_name!="")
			{
			move_uploaded_file($image_path,'student_images/'.$image_name);	
			
			}
			
			$sql = "insert into student_details values('$student_membership_id','$student_first_name','$student_middle_name','$student_last_name','$student_email','$student_course','$student_year','$student_number','$student_address','$student_city','$student_state','$student_pin_code','$image_name');";
			
			$query = mysql_query($sql);
			}?>

                                        </div>
                                    </div>
                                    </div>
                            </div>
                            
                        </div>
                        
                        
                        
                        
                        
                        
                    
            
            			
			<div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body" id="lol" style="display:none">
                                       <h5 class="text-muted">Recent Details Uploaded!</h5>									
									
					
                                   <?php 
								   $sql1 = "select max(Membership_Id) as total from student_details;";
								   $query1 = mysql_query($sql1);
								   $data = mysql_fetch_array($query1);
								   $row1 =  $data['total'];
								   
								   $sql2 = "select * from student_details where Membership_Id = $row1";
								   $query2 = mysql_query($sql2);
								   
                                   
								   while($row2 = mysql_fetch_array($query2))
								   { ?>
                                   <img src="/Library_Management/student_images/<?php echo $row2['Photo'];?>" style = "height:100px;width:80px;margin:25px 75px">
				<?php
									   
									   echo $row2['Membership_Id']."<br>";
									   echo $row2['First_Name']."<br>";
									   echo $row2['Middle_Name']."<br>";
									   echo $row2['Last_Name']."<br>";
									   echo $row2['Email']."<br>";
									   echo $row2['Course']."<br>";
									   echo $row2['Year']."<br>";
									   echo $row2['Phone_Number']."<br>";
									   echo $row2['Address']."<br>";
									   echo $row2['City']."<br>";
									   echo $row2['State']."<br>";
									   echo $row2['PinCode']."<br>";
									  
                				} ?>
                                
										<input type = "button" value = "close" onclick="document.getElementById('lol').remove()"/>
                                      </div>
                                      
                                    </div>
                            </div>
                            </div>
                </div>
           <?php include "footer.php" ?>
