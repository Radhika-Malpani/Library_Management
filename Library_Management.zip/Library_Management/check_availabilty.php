<?php 
include "header.php";
include "connection.php";
?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Check Book Availability</h5>
                                           <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
                                            <form method = "post">
                                        <input type = "text" name = "book_search" placeholder = "Enter the Keywords" width="100%"/>
                                        <input type = "submit" name = "check" value = "Save" />
                                        </form>
                                        </div>
                                    </div>
                                   </div>
                                   </div> 
                            </div>
                         </div>
                                        
                                        <div class="row">
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Search Result</h5>
                                           <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
										<?php
										if(isset($_POST['check']))
										{
										$book_search = $_POST['book_search'];
										$course = "select * from book_details where Title like '%$book_search%' AND Issue != 'Yes' ;";
										
										
										$query_course1 = mysql_query($course);
										if(!$query_course1)
										{
											echo "<script> alert('NO BOOK AVAILABLE AT THE MOMENT!!!!'); </script>";	
										}
										?>
                                        <table border="1px solid grey" >
                                        <tr><th>Isbn</th><th>Book_No.</th><th>Author</th><th>Title</th><th>Category</th><th>Publisher</th><th>Description</th><th>Image</th><th>Action</th></tr>
                                        <?php
										while($row1 = mysql_fetch_array($query_course1))
										{
											
											echo "<tr><td>";
											echo $row1['Isbn'];
											echo "</td><td>";
											echo $row1['Book_number'];
											echo "</td><td>";
											echo $row1['Author'];
											echo "</td><td>";
											echo $row1['Title'];
											echo "</td><td>";
											echo $row1['Category'];
											echo "</td><td>";
											echo $row1['Publisher'];
											echo "</td><td>";
											echo $row1['Description'];
											echo "</td><td>";
											$image = $row1['Image'];
											?>
                                            <img src="/Library_Management/book_images/<?php echo $image; ?>" height="100px" width="50px"/>
                                            <td><input type = "button" name = "book_issue" value = "Issue Book" onclick="window.location.href='issue.php?book_number=<?php echo $row1['Book_number']; ?>'" /><td></tr>
										<?php } ?>
                                        </table>
                                        <?php
										}
										?>
                                        </div>
                                    </div>
                                   </div>
                                   </div> 
                            </div>
                         </div>
                         					<?php				include "footer.php"							
										?>
                         
            
