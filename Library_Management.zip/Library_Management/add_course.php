<?php 
include "header.php";
include "connection.php";
?>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">GLOBAL LIBRARY SYSTEM </h2>
                                <p class="pageheader-text">Nulla euismod urna eros, sit amet scelerisque torton lectus vel mauris facilisis faucibus at enim quis massa lobortis rutrum.</p>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Welcome to GLOBAL LIBRARY SYSTEM</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader  -->
                    <!-- ============================================================== -->
                    <div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Add Course Name</h5>
                                           <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
                                            <form method = "post">
                                        <input type = "text" name = "course" placeholder = "Course Name : E.g. Computer, IT..." width="100%"/>
                                        <input type = "submit" name = "submit_course" value = "Save" />
                                        </form>
										
                                        </div>
                                    </div>
                                   </div>
                                   </div> 
                            </div>
                         </div>
                         <?php
										if(isset($_POST['submit_course']))
										{
										$course = $_POST['course'];
										$sql_course = "insert into course_details values(null,'$course');";
										echo $sql_course;
										$query_course = mysql_query($sql_course);
										}
										
										?>
                         <div class ="row">
                            <div class="col-xl-9 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Course List</h5>
                                        <div class="metric-value d-inline-block">
                                            <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post" enctype="multipart/form-data">
            <table border="1px solid grey" style="border-collapse:collapse">
            
				<tr> <th>Courses</th> <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Action</th> </tr>
                <?php 
				$sql_show_course = "select * from course_details;";
				$query_show_course = mysql_query($sql_show_course);
				while($row = mysql_fetch_array($query_show_course))
				{
					$id = $row['Course_Id'];
				?>
                <tr><td><?php echo $row['Course_Name']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td><td><?php echo "<a href='edit_course.php?id=$id' target='_blank'>Edit</a>"; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo "<a href='delete_course.php?id=$id' target='_blank'>Delete</a>"; ?> </td></tr>
                <?php } ?>
             </table>
                
</form>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <?php
			if(isset($_POST['submit']))
			{
			$book_isbn = $_POST['book_isbn'];
			$book_author = $_POST['book_author'];	
			$book_title = $_POST['book_title'];	
			$book_category = $_POST['book_category'];	
			$book_publisher = $_POST['book_publisher'];	
			$book_description = $_POST['book_description'];	
			$book_price = $_POST['book_price'];	
			$book_quantity = $_POST['book_quantity'];	
			$book_image = $_FILES['book_image'];
			$image_name = $book_image['name'];
			$image_path = $book_image['tmp_name'];
			
			if($image_name!="")
			{
			move_uploaded_file($image_path,'book_images/'.$image_name);	
			
			}
			
			$sql = "insert into book_details values('$book_isbn','$book_author','$book_title','$book_category','$book_publisher','$book_description','$book_price','$book_quantity','$image_name');";
			
			$query = mysql_query($sql);
			}
            include "footer.php" ?>
