<?php include "connection.php";
include "header.php"?>
<style>
.bg-modal{
width:100%;
height:100%;
background-color: rgba(0, 0, 0, 0.1);
position:relative;
top:0;	
justify-content:center;
align-items:center;
display:none;
margin-left:100px;
margin-right:100px;
}
.modal-content{
	width:500px;
	height:300px;
	background-color:white;
	border-radius:4px;
	text-align:center;
	padding:20px;
}
</style>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
<?php
$sql = "select * from issue_details";
$query = mysql_query($sql);?>
<div style="overflow-x:auto;">
<table border="1px solid grey" style="border-collapse:collapse;padding:500px;text-align:center">
<tr>
    <th>BOOK_NUMBER</th>
    <th>MEMBERSHIP_NUMBER</th>
    
</tr>
<?php
while($row = mysql_fetch_array($query))
{
	echo "<tr><td>";
	echo $row['Book_number'];
	$Book_number = $row['Book_number'];
	echo "</td><td>";
	
	
	
	$Mem_Id = $row['Mem_Id'];
	echo $row['Mem_Id'];
		
	echo "</td><td>";
	
	
	echo $row['Issue_Date'];
	$Issue_Date = $row['Issue_Date'];
	echo "</td><td>";
	
	
	echo $row['Return_Date'];
	$Return_Date = $row['Return_Date'];
	echo "</td><td>";
	
	
		?>
    
    <input type = "button" id = "issue_details" value = "Issue Details" onclick="demo(<?php echo $Book_number; ?>,<?php echo $Mem_Id; ?>,'<?php echo $Issue_Date; ?>','<?php echo $Return_Date ; ?>')"/>
	</td></tr>
   
    <?php
}

?>
</table>

</div>
<script>
function demo(book_no,student_no,id,rd)
{

document.getElementById('mymodal').style.display = 'block';
document.getElementById('book').innerHTML = book_no;
document.getElementById('stud').innerHTML = student_no;
document.getElementById('id').innerHTML = id;
document.getElementById('rm').innerHTML = rd;
}

</script>
<!--Modal-->
<div class="bg-modal" id="mymodal">
<div class="modal-content">

<p id="book">

</p>
<p id="stud">

</p>
<p id="id">

</p>
<p id="rd">

</p>


</div>
</div>

<?php include "footer.php"; ?>