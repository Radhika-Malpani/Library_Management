<?php include "connection.php";
include "header.php";
$book_id = $_GET['id'];


$check = "select Fine from issue_details where Book_number = '$book_id';";
$check_query = mysql_query($check);
while($row = mysql_fetch_array($check_query))
{
	$fine = $row['Fine'];
	if($fine > 0)
	{
		echo "<script> 
		alert('Your Fine Is Pending for this book');
		window.location.href='calculate_fine.php';</script>";
	}
	else
	{
	$sql = "delete from issue_details where Book_number='$book_id';";
	$query = mysql_query($sql);
	
	
	}
}

