<?php include "connection.php";
include "header.php"?>
<style>
.bg-modal{
width:100%;
height:100%;
background-color: rgba(0, 0, 0, 0.7);
position:relative;
top:0;	
justify-content:center;
align-items:center;
display:none;
margin-left:100px;
margin-right:100px;
}
.modal-content{
	width:500px;
	height:600px;
	background-color:white;
	border-radius:4px;
	text-align:center;
	padding:20px;
}
</style>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
<?php
$today = date("Y-m-d");
//echo $today;
$sql = "select * from issue_details where Return_Date < '$today'";
//echo $sql;
$query = mysql_query($sql);?>
<div style="overflow-x:auto;">

<?php
while($row = mysql_fetch_array($query))
{
	
	$Book_number = $row['Book_number'];
	$Return_Date = $row['Return_Date'];
	
	
	
	$date1=date_create($Return_Date);
	$date2=date_create($today);

	$d1 = date_format($date1,"d-m-y");
	$d2 = date_format($date2,"d");

	$m1 =date_format($date1,"m");
	$m2= date_format($date2,"m");
	
	$datediff = $d2-$d1;
	
	$sql1 = "update issue_details set Fine='$datediff' where Book_number='$Book_number';";
	$query1=mysql_query($sql1); 
	echo "</td></tr>";
	
}
?>
<table border="1px solid grey" style="border-collapse:collapse;text-align:center">
<tr>
	<th>BOOK_NUMBER</th>
    <th>MEMBERSHIP_NO</th>
    <th>ISSUE DATE</th>
    <th>RETURN DATE</th>
    <th>FINE</th>
    <th>PAY</th>
</tr>
<?php
	$sql1 = "select * from issue_details where Return_Date < '$today'";
//echo $sql;
$query1 = mysql_query($sql1);
while($row1 = mysql_fetch_array($query1))
{
	echo "<tr><td>";
	$Book_number = $row1['Book_number'];
	echo $row1['Book_number'];
	echo "</td><td>";
	
	
	echo $row1['Mem_Id'];
	$Mem_Id = $row1['Mem_Id'];
	echo "</td><td>";
	
	
	echo $row1['Issue_Date'];
	$Issue_Date = $row1['Issue_Date'];
	echo "</td><td>";
	
	
	echo $row1['Return_Date'];
	$Return_Date = $row1['Return_Date'];
	echo "</td><td>";
	
	echo "Rs.".$row1['Fine'];
	$Return_Date = $row1['Fine'];
	echo "</td><td>";

?>
	<input type="submit" value="Pay Now" onclick="window.location.href='pay_fine.php?id=<?php echo $Book_number; ?>'" /></td></tr>
    <?php } ?>
	</table>
    
   
</div>
<!--Modal-->

</div>
</div>

<?php include "footer.php"; ?>