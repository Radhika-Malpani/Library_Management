<?php
include "connection.php";

$id = $_GET['id'];

$sql = "update issue_details set Fine='0' where Book_number='$id'";
echo $sql;
$query=mysql_query($sql);
if($query)
{
	echo "<script> alert('Fine Cleared'); </script>";
}
$sql1 = "update issue_details set Return_Date='NA' where Book_number='$id'";
$query=mysql_query($sql1);



?>