<?php include "connection.php";
include "header.php"?>
<style>
.bg-modal{
width:100%;
height:100%;
background-color: rgba(0, 0, 0, 0.1);
position:relative;
top:0;	
justify-content:center;
align-items:center;
display:none;
margin-left:100px;
margin-right:100px;
}
.modal-content{
	width:500px;
	height:400px;
	background-color:white;
	border-radius:4px;
	text-align:center;
	padding:20px;
}
</style>
<div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
<?php
$sql = "select * from book_details";
$query = mysql_query($sql);?>
<div style="overflow-x:auto;">
<table border="1px solid grey" style="padding:500px;text-align:center">
<tr>
	<th>BOOK COVER</th>
    <th>ISBN</th>
    <th>BOOK NUMBER</th>
    <th>AUTHOR</th>
    <th>TITLE</th>
    <th>CATEGORY</th>
    <th>PUBLISHER</th>
    <th>DESCRIPTION</th>
    <th>PRICE</th>
    <th>ACTION</th>
</tr>
<?php
while($row = mysql_fetch_array($query))
{
	echo "<tr><td>";
	$image = $row['Image'];
	?>
    <img src="/Library_Management/book_images/<?php echo $image; ?>" height="100px" width="100px" />
    <?php
	echo "</td><td>";
	
	
	echo $row['Isbn'];
	$isbn = $row['Isbn'];
	echo "</td><td>";
	
	
	echo $row['Book_number'];
	$Book_number = $row['Book_number'];
	echo "</td><td>";
	
	
	$author = $row['Author'];
	echo $row['Author'];
	echo "</td><td>";
	
	
	echo $row['Title'];
	$title = $row['Title'];
	echo "</td><td>";
	
	
	echo $row['Category'];
	$category = $row['Category'];
	echo "</td><td>";
	
	
	echo $row['Publisher'];
	$publisher = $row['Publisher'];
	echo "</td><td>";
	
	
	echo $row['Description'];
	$description = $row['Description'];
	echo "</td><td>";
	
	
	echo $row['Price'];
	$price = $row['Price'];
	echo "</td><td>";
	
	
	?>
    
    <input type = "button" id = "details" value = "Book Details" onclick="demo(<?php echo $isbn; ?>,'<?php echo $Book_number; ?>','<?php echo $author; ?>','<?php echo $title; ?>','<?php echo $category ; ?>','<?php echo $publisher; ?>','<?php echo $description; ?>',<?php echo $price; ?>)"/>
	</td></tr>
   
    <?php
}

?>
</table>
</div>
<script>
function demo(isbn,Book_number,author,title,category,publisher,description,price)
{

document.getElementById('mymodal').style.display = 'block';
document.getElementById('isbn').innerHTML = isbn;
document.getElementById('Book_number').innerHTML = Book_number;
document.getElementById('author').innerHTML = author;
document.getElementById('title').innerHTML = title;
document.getElementById('category').innerHTML = category;
document.getElementById('publisher').innerHTML = publisher;
document.getElementById('description').innerHTML = description;
document.getElementById('price').innerHTML = price;



}

</script>
<!--Modal-->
<div class="bg-modal" id="mymodal">
<div class="modal-content">

<p id="isbn">

</p>
<p id="Book_number">

</p>
<p id="author">

</p>
<p id="title">

</p>
<p id="category">

</p>
<p id="publisher">

</p>
<p id="description">

</p>
<p id="price">

</p>
</div>
</div>

<?php include "footer.php"; ?>