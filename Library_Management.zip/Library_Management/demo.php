
<?php echo "<script> var n=10; document.write(n); </script>";
?>